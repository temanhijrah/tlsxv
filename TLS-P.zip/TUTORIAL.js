script Ddos via termux By TZyoxC🚀

telegram : @TZyoxC
chenel : @TZyoxC_Proff

1.UnArchive script ini menjadi folder di bagian utama

2.masuk ke termux tempel command ini 
1.pkg upgrade && pkg update 
2.termux-setup-storage
3.termux-change-repo 
4.pkg install nodejs 
5.cd /sdcard/TLS-P
6.node TLS-P.js 

Jika eror pake command kedua
cd TLS-P
cd /sdcard
cp -r TLS-P $HOME
cd
cd TLS-P
npm i
node TLS-P.js

minimal credits lah😏😏

